
const products = window.PRODUCTS || [];
const categories = [
  ["all","全部产品","All Products"],
  ["long","长款雨衣","Long Raincoats"],
  ["suit","分体套装","Rain Suits"],
  ["work","反光工作","Reflective Workwear"],
  ["riding","骑行雨衣","Cycling Rainwear"],
  ["camouflage","迷彩系列","Camouflage"],
  ["winter","保暖防护","Insulated Workwear"],
  ["pants","雨裤单品","Rain Pants"],
  ["other","其他防护","Other Protection"]
];
let lang = "zh";
let activeCategory = "all";
let visibleCount = 12;
let currentProduct = null;

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const menuBtn = $(".menu-btn");
const nav = $(".main-nav");
const searchInput = $("#productSearch");
const grid = $("#catalogGrid");
const filterChips = $("#filterChips");
const loadMore = $("#loadMore");
const resultCount = $("#resultCount");
const productSelect = $("#productSelect");
const modal = $("#productModal");
const modalImage = $("#modalImage");
const modalThumbs = $("#modalThumbs");

function t(zh,en){ return lang === "zh" ? zh : en; }

menuBtn?.addEventListener("click",()=>{
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", String(open));
});
$$(".main-nav a").forEach(a=>a.addEventListener("click",()=>{
  nav.classList.remove("open");
  menuBtn?.setAttribute("aria-expanded","false");
}));

function applyLanguage(next){
  lang = next;
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
  $$("[data-zh][data-en]").forEach(el=>el.textContent=el.dataset[lang]);
  $$("[data-ph-zh][data-ph-en]").forEach(el=>el.placeholder=lang==="zh"?el.dataset.phZh:el.dataset.phEn);
  $(".lang-btn").textContent = lang === "zh" ? "EN" : "中文";
  renderFilters();
  renderProducts();
  fillProductSelect();
  if(currentProduct) updateModalText(currentProduct);
}
$(".lang-btn")?.addEventListener("click",()=>applyLanguage(lang==="zh"?"en":"zh"));

function renderFilters(){
  const counts = products.reduce((acc,p)=>{acc[p.category]=(acc[p.category]||0)+1;return acc;},{});
  filterChips.innerHTML = categories.map(([key,zh,en])=>{
    const count = key === "all" ? products.length : (counts[key]||0);
    return `<button class="filter-chip ${activeCategory===key?"active":""}" data-filter="${key}" type="button">${t(zh,en)} <small>${count}</small></button>`;
  }).join("");
  $$(".filter-chip").forEach(btn=>btn.addEventListener("click",()=>{
    activeCategory=btn.dataset.filter;
    visibleCount=12;
    renderFilters();
    renderProducts();
  }));
}
function filteredProducts(){
  const q=(searchInput?.value||"").trim().toLowerCase();
  return products.filter(p=>{
    const inCat=activeCategory==="all"||p.category===activeCategory;
    const hay=[p.nameZh,p.nameEn,p.sku,p.colorsZh,p.colorsEn,p.categoryZh,p.categoryEn].join(" ").toLowerCase();
    return inCat && (!q || hay.includes(q));
  });
}
function productCard(p){
  const name=t(p.nameZh,p.nameEn);
  const cat=t(p.categoryZh,p.categoryEn);
  const tags=(lang==="zh"?p.featuresZh:p.featuresEn).slice(0,2);
  return `<article class="product-card" tabindex="0" data-product-id="${p.id}">
    <div class="product-image"><img loading="lazy" src="${p.images[0]}" alt="${name}"><span class="product-code">${p.sku}</span></div>
    <div class="product-info"><span class="product-category">${cat}</span><h3>${name}</h3>
      <div class="product-tags">${tags.map(x=>`<span>${x}</span>`).join("")}</div>
      <div class="product-action"><b>${t("查看详情","View Details")}</b><span>${t("价格请询价","Contact for Quote")} →</span></div>
    </div></article>`;
}
function renderProducts(){
  const list=filteredProducts();
  grid.innerHTML=list.slice(0,visibleCount).map(productCard).join("");
  resultCount.textContent=t(`共找到 ${list.length} 款产品`,`Found ${list.length} products`);
  loadMore.style.display=list.length>visibleCount?"inline-flex":"none";
  $$(".product-card").forEach(card=>{
    const open=()=>openModal(products.find(p=>String(p.id)===card.dataset.productId));
    card.addEventListener("click",open);
    card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}});
  });
}
searchInput?.addEventListener("input",()=>{visibleCount=12;renderProducts();});
loadMore?.addEventListener("click",()=>{visibleCount+=12;renderProducts();});
$$("[data-category-jump]").forEach(btn=>btn.addEventListener("click",()=>{
  activeCategory=btn.dataset.categoryJump;
  visibleCount=12;
  renderFilters();renderProducts();
  $("#catalog").scrollIntoView({behavior:"smooth"});
}));

function setModalImage(src,index){
  modalImage.src=src;
  $$("#modalThumbs button").forEach((b,i)=>b.classList.toggle("active",i===index));
}
function updateModalText(p){
  $("#modalCategory").textContent=t(p.categoryZh,p.categoryEn);
  $("#modalTitle").textContent=t(p.nameZh,p.nameEn);
  $("#modalModel").textContent=p.sku;
  $("#modalColors").textContent=t(p.colorsZh,p.colorsEn);
  $("#modalMaterial").textContent=t(p.materialZh,p.materialEn);
  const tags=lang==="zh"?p.featuresZh:p.featuresEn;
  $("#modalTags").innerHTML=tags.map(x=>`<span>${x}</span>`).join("");
}
function openModal(p){
  if(!p) return;
  currentProduct=p;
  updateModalText(p);
  modalThumbs.innerHTML=p.images.map((src,i)=>`<button class="${i===0?"active":""}" type="button" data-src="${src}" data-index="${i}"><img src="${src}" alt=""></button>`).join("");
  setModalImage(p.images[0],0);
  $$("#modalThumbs button").forEach(b=>b.addEventListener("click",()=>setModalImage(b.dataset.src,Number(b.dataset.index))));
  modal.classList.add("open");
  modal.setAttribute("aria-hidden","false");
  document.body.classList.add("modal-open");
}
function closeModal(){
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden","true");
  document.body.classList.remove("modal-open");
}
$$("[data-close-modal]").forEach(el=>el.addEventListener("click",closeModal));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
$("#modalInquiry")?.addEventListener("click",()=>{
  if(currentProduct){
    productSelect.value=String(currentProduct.id);
    closeModal();
    $("#contact").scrollIntoView({behavior:"smooth"});
  }
});

function fillProductSelect(){
  const current=productSelect.value;
  productSelect.innerHTML=`<option value="">${t("请选择产品","Select a product")}</option>`+
    products.map(p=>`<option value="${p.id}">${p.sku} · ${t(p.nameZh,p.nameEn)}</option>`).join("");
  if(current) productSelect.value=current;
}
const quoteForm=$("#quoteForm");
quoteForm?.addEventListener("submit",async e=>{
  e.preventDefault();
  if(!quoteForm.reportValidity()) return;

  const submitButton=quoteForm.querySelector('button[type="submit"]');
  const formStatus=$("#formStatus");
  const fd=new FormData(quoteForm);
  const selected=products.find(p=>String(p.id)===fd.get("product"));

  fd.set("product",selected?`${selected.sku} · ${t(selected.nameZh,selected.nameEn)}`:t("未选择","Not selected"));
  fd.set("language",lang==="zh"?"中文":"English");
  fd.set("page_url",window.location.href);
  fd.set("submitted_at",new Date().toLocaleString());
  fd.set("_subject",`${t("雨时亿官网产品询价","Yushiyi Website Inquiry")}｜${fd.get("name")}`);

  submitButton.disabled=true;
  submitButton.textContent=t("正在提交…","Submitting…");
  formStatus.hidden=false;
  formStatus.className="form-status full is-loading";
  formStatus.textContent=t("正在提交询价，请稍候…","Submitting your inquiry, please wait…");

  try{
    const response=await fetch("https://formsubmit.co/ajax/3023210144@qq.com",{
      method:"POST",
      headers:{"Accept":"application/json"},
      body:fd
    });
    const result=await response.json().catch(()=>({}));
    if(!response.ok||result.success===false){
      throw new Error(result.message||`HTTP ${response.status}`);
    }
    quoteForm.reset();
    fillProductSelect();
    formStatus.className="form-status full is-success";
    formStatus.textContent=t("提交成功！我们会尽快与您联系。","Submitted successfully! We will contact you shortly.");
  }catch(error){
    console.error("Inquiry submission failed:",error);
    formStatus.className="form-status full is-error";
    formStatus.textContent=t("提交暂时失败，请稍后重试，或直接联系 3023210144@qq.com。","Submission failed. Please try again or contact 3023210144@qq.com.");
  }finally{
    submitButton.disabled=false;
    submitButton.textContent=t("提交询价","Submit Inquiry");
  }
});
$("#year").textContent=new Date().getFullYear();
renderFilters();renderProducts();fillProductSelect();
